import api from './axios'

/* ================= CONTRACTS ================= */
export const getContracts = (query = {}) => api.get('/contracts', { params: query })
export const getContractById = (id) => api.get(`/contracts/${id}`)
export const createContract = (payload) => api.post('/contracts', payload)
export const updateContract = (id, payload) => api.patch(`/contracts/${id}`, payload)
export const deleteContract = (id) => api.delete(`/contracts/${id}`)

/* ================= INVOICES ================= */
export const getInvoices = (query = {}) => api.get('/invoices', { params: query })
export const getInvoiceById = (id) => api.get(`/invoices/${id}`)
export const createInvoice = (payload) => api.post('/invoices', payload)
export const updateInvoice = (id, payload) => api.patch(`/invoices/${id}`, payload)
export const deleteInvoice = (id) => api.delete(`/invoices/${id}`)

/* ================= BATCHES ================= */
export const getBatches = (query = {}) => api.get('/batches', { params: query })
export const getBatchById = (id) => api.get(`/batches/${id}`)
export const createBatch = (payload) => api.post('/batches', payload)
export const updateBatch = (id, payload) => api.patch(`/batches/${id}`, payload)
export const deleteBatch = (id) => api.delete(`/batches/${id}`)

export const getNearExpiry = (days = 30) =>
  api.get('/batches/near-expiry', { params: { days } })

/* ================= MARKING ================= */
export const getMarkingCodes = (batchId, available = false) =>
  api.get(`/batches/${batchId}/marking-codes`, {
    params: available ? { available: true } : {},
  })

export const addMarkingCodes = (batchId, codes) =>
  api.post(`/batches/${batchId}/marking-codes`, { codes })

export const exportMarkingCodes = (batchId) =>
  api.get(`/batches/${batchId}/marking-codes/export`)